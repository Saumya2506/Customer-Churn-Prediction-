"""Analytics Streamlit suite package."""
